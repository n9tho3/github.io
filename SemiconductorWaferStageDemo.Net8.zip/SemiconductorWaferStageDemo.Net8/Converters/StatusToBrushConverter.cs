﻿using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;

namespace SemiconductorWaferStageDemo.Net8.Converters;

public class StatusToBrushConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        if (value is string status)
        {
            return status switch
            {
                "控制器连接成功" => Brushes.Green,
                "未连接" => Brushes.Gray,
                _ => Brushes.Red
            };
        }
        return Brushes.Gray;
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
    {
        throw new NotImplementedException();
    }
}
