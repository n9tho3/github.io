﻿using SemiconductorWaferStageDemo.Net8.ViewModels;

namespace SemiconductorWaferStageDemo.Net8;

public partial class MainWindow
{
    public MainWindow()
    {
        InitializeComponent();
        // .NET 8 简化绑定，直接实例化视图模型，大型项目可替换为原生DI注入
        DataContext = new MainViewModel();
    }
}
