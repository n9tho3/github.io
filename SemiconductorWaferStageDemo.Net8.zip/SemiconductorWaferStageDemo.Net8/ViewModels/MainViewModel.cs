﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using SemiconductorWaferStageDemo.Net8.ModbusDriver;
using System.Data;

namespace SemiconductorWaferStageDemo.Net8.ViewModels;

public partial class MainViewModel : ObservableObject
{
    private readonly ICommDriver _driver;

    // .NET 8 CommunityToolkit.Mvvm 特性：自动生成属性变更通知，不需要手动写代码
    [ObservableProperty]
    [NotifyPropertyChangedFor(nameof(PositionRefreshEnabled))]
    private string _connectionStatus = "未连接";

    [ObservableProperty] private double _currentX;
    [ObservableProperty] private double _currentY;
    [ObservableProperty] private double _targetX;
    [ObservableProperty] private double _targetY;
    [ObservableProperty] private string _selectedPort = "COM3";
    [ObservableProperty] private int _selectedBaud = 9600;

    // 控制按钮可用性：只有连接成功后才能操作
    public bool PositionRefreshEnabled => _connectionStatus == "控制器连接成功";

    public MainViewModel()
    {
        // 依赖注入Demo简化，直接实例化驱动，大型项目可以用.NET 8原生DI容器
        _driver = new ModbusRtuDriver();
    }

    // 特性自动生成命令，不需要手动实例化ICommand
    [RelayCommand(CanExecute = nameof(PositionRefreshEnabled))]
    private void ConnectController()
    {
        bool result = _driver.Connect(_selectedPort, _selectedBaud);
        _connectionStatus = result ? "控制器连接成功" : "控制器连接失败";
    }

    [RelayCommand]
    private void DisconnectController()
    {
        _driver.Disconnect();
        _connectionStatus = "未连接";
    }

    [RelayCommand(CanExecute = nameof(PositionRefreshEnabled))]
    private void RefreshPosition()
    {
        if (_driver.ReadRegisters(0, out ushort[] positions))
        {
            _currentX = positions[0];
            _currentY = positions[1];
        }
    }

    [RelayCommand(CanExecute = nameof(PositionRefreshEnabled))]
    private void MoveWaferStage()
    {
        ushort targetX = (ushort)Math.Clamp(_currentX, 0, 500); // .NET 8原生Math.Clamp限制范围，避免越界
        ushort targetY = (ushort)Math.Clamp(_currentY, 0, 500);
        ushort[] targetPos = [targetX, targetY]; // .NET 8 集合表达式语法，更简洁

        if (_driver.WriteRegisters(100, targetPos))
        {
            RefreshPosition();
        }
    }
}
