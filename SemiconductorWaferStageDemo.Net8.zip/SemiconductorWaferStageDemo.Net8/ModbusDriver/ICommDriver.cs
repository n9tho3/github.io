﻿using System;

namespace SemiconductorWaferStageDemo.Net8.ModbusDriver;

/// <summary>
/// 硬件控制器通用通讯驱动接口
/// </summary>
public interface ICommDriver
{
    /// <summary>
    /// 连接控制器
    /// </summary>
    /// <param name="portName">串口名称</param>
    /// <param name="baudRate">波特率</param>
    /// <returns>连接是否成功</returns>
    bool Connect(string portName, int baudRate);

    /// <summary>
    /// 断开控制器连接，释放资源
    /// </summary>
    void Disconnect();

    /// <summary>
    /// 读取保持寄存器数据
    /// </summary>
    /// <param name="startAddr">起始地址</param>
    /// <param name="values">输出的寄存器值</param>
    /// <returns>读取是否成功</returns>
    bool ReadRegisters(ushort startAddr, out ushort[] values);

    /// <summary>
    /// 写入多个保持寄存器
    /// </summary>
    /// <param name="startAddr">起始地址</param>
    /// <param name="values">要写入的值</param>
    /// <returns>写入是否成功</returns>
    bool WriteRegisters(ushort startAddr, ushort[] values);
}
