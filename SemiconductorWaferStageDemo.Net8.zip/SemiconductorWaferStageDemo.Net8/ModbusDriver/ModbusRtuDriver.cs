﻿using System;
using System.IO.Ports;
using System.Threading;

namespace SemiconductorWaferStageDemo.Net8.ModbusDriver;

public class ModbusRtuDriver : ICommDriver
{
    private SerialPort? _serialPort;
    private bool _isConnected;

    public bool Connect(string portName, int baudRate)
    {
        try
        {
            // .NET 8 SerialPort参数初始化，适配Modbus-RTU标准参数
            _serialPort = new SerialPort(portName, baudRate, Parity.None, 8, StopBits.One)
            {
                ReadTimeout = 500, // 读取超时时间，单位毫秒，适配工业设备响应速度
                WriteTimeout = 500
            };

            _serialPort.Open();
            _isConnected = true;
            return true;
        }
        catch (Exception ex)
        {
            // .NET 8 字符串插值语法，更简洁
            Console.WriteLine($"控制器连接失败：{ex.Message}");
            _isConnected = false;
            return false;
        }
    }

    public void Disconnect()
    {
        if (_serialPort is { IsOpen: true })
        {
            _serialPort.Close();
            _serialPort.Dispose();
        }
        _isConnected = false;
        _serialPort = null;
    }

    public bool ReadRegisters(ushort startAddr, out ushort[] values)
    {
        values = Array.Empty<ushort>();
        if (!_isConnected || _serialPort == null) return false;

        try
        {
            // 拼接Modbus-RTU 读保持寄存器指令：从站地址01 功能码03 起始地址 读取长度2字节 CRC校验（Demo省略校验，实际开发必须添加）
            byte[] readCommand = { 0x01, 0x03, (byte)(startAddr >> 8), (byte)(startAddr & 0xFF), 0x00, 0x02, 0x79, 0x96 };

            _serialPort.Write(readCommand, 0, readCommand.Length);
            // 等待硬件响应，适配.NET 8 Thread休眠优化
            Thread.Sleep(10);

            if (_serialPort.BytesToRead <= 0) return false;
            byte[] buffer = new byte[_serialPort.BytesToRead];
            _serialPort.Read(buffer, 0, buffer.Length);

            // Demo简化：模拟解析返回晶圆平台X/Y轴位置，实际开发替换为真实报文解析逻辑
            values = new ushort[2];
            values[0] = 125; // X轴当前位置，单位：0.01mm
            values[1] = 80;  // Y轴当前位置，单位：0.01mm
            return true;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"读取寄存器失败：{ex.Message}");
            return false;
        }
    }

    public bool WriteRegisters(ushort startAddr, ushort[] values)
    {
        if (!_isConnected || _serialPort == null) return false;
        try
        {
            // Demo简化：模拟下发目标位置指令，实际开发拼接Modbus写寄存器报文+CRC校验发送
            Console.WriteLine($"下发控制指令：起始地址{startAddr}，目标X={values[0]}, 目标Y={values[1]}");
            return true;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"写入寄存器失败：{ex.Message}");
            return false;
        }
    }
}
