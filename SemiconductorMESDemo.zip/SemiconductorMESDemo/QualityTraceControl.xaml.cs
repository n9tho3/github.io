﻿using System.Data;
using System.Windows.Controls;
using System.Windows;
using SemiconductorMESDemo.Helper;
using System.Data.SqlClient;

namespace SemiconductorMESDemo
{
    public partial class QualityTraceControl : UserControl
    {
        public QualityTraceControl()
        {
            InitializeComponent();
        }

        private void BtnQuery_Click(object sender, RoutedEventArgs e)
        {
            string waferId = tbWaferId.Text.Trim();
            if (string.IsNullOrEmpty(waferId))
            {
                System.Windows.MessageBox.Show("请输入要查询的晶圆ID！");
                return;
            }

            string sql = @"SELECT w.OrderID as 工单号, w.ProductName as 产品名称, e.EqpName as 测试设备, 
                          ed.TestParam as 测试参数, ed.TestValue as 测试值, ed.IsPass as 是否合格, ed.CollectTime as 采集时间
                          FROM Mes_EquipmentData ed
                          LEFT JOIN Mes_WorkOrder w ON ed.OrderID = w.OrderID
                          LEFT JOIN Mes_Equipment e ON ed.EqpID = e.EqpID
                          WHERE ed.WaferID = @WaferId";
            DataTable dt = SqlHelper.GetDataTable(sql, new SqlParameter("@WaferId", waferId));
            if (dt.Rows.Count == 0)
            {
                System.Windows.MessageBox.Show("未找到该晶圆的相关数据！");
                return;
            }

            dt.Columns["是否合格"].ReadOnly = false;
            foreach (DataRow row in dt.Rows)
            {
                bool pass = bool.Parse(row["是否合格"].ToString());
                row["是否合格"] = pass ? "合格" : "不合格";
            }
            dgTraceResult.ItemsSource = dt.DefaultView;
        }
    }
}
