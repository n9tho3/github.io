﻿namespace SemiconductorMESDemo
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.elementHost1 = new System.Windows.Forms.Integration.ElementHost();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.生产工单管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.设备数据采集ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.质量追溯ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.异常处理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // elementHost1
            // 
            this.elementHost1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.elementHost1.Location = new System.Drawing.Point(0, 25);
            this.elementHost1.Name = "elementHost1";
            this.elementHost1.Size = new System.Drawing.Size(884, 486);
            this.elementHost1.TabIndex = 0;
            this.elementHost1.Text = "elementHost1";
            this.elementHost1.Child = null;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.生产工单管理ToolStripMenuItem,
            this.设备数据采集ToolStripMenuItem,
            this.质量追溯ToolStripMenuItem,
            this.异常处理ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(884, 25);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 生产工单管理ToolStripMenuItem
            // 
            this.生产工单管理ToolStripMenuItem.Name = "生产工单管理ToolStripMenuItem";
            this.生产工单管理ToolStripMenuItem.Size = new System.Drawing.Size(92, 21);
            this.生产工单管理ToolStripMenuItem.Text = "生产工单管理";
            this.生产工单管理ToolStripMenuItem.Click += new System.EventHandler(this.生产工单管理ToolStripMenuItem_Click);
            // 
            // 设备数据采集ToolStripMenuItem
            // 
            this.设备数据采集ToolStripMenuItem.Name = "设备数据采集ToolStripMenuItem";
            this.设备数据采集ToolStripMenuItem.Size = new System.Drawing.Size(92, 21);
            this.设备数据采集ToolStripMenuItem.Text = "设备数据采集";
            this.设备数据采集ToolStripMenuItem.Click += new System.EventHandler(this.设备数据采集ToolStripMenuItem_Click);
            // 
            // 质量追溯ToolStripMenuItem
            // 
            this.质量追溯ToolStripMenuItem.Name = "质量追溯ToolStripMenuItem";
            this.质量追溯ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.质量追溯ToolStripMenuItem.Text = "质量追溯";
            this.质量追溯ToolStripMenuItem.Click += new System.EventHandler(this.质量追溯ToolStripMenuItem_Click);
            // 
            // 异常处理ToolStripMenuItem
            // 
            this.异常处理ToolStripMenuItem.Name = "异常处理ToolStripMenuItem";
            this.异常处理ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.异常处理ToolStripMenuItem.Text = "异常处理";
            this.异常处理ToolStripMenuItem.Click += new System.EventHandler(this.异常处理ToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 511);
            this.Controls.Add(this.elementHost1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "半导体MES Demo";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Integration.ElementHost elementHost1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 生产工单管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 设备数据采集ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 质量追溯ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 异常处理ToolStripMenuItem;
    }
}

