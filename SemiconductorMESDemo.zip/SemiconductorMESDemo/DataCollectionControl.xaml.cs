﻿using System;
using System.Data;
using System.Timers;
using System.Windows.Controls;
using System.Windows;
using SemiconductorMESDemo.Helper;
using System.Data.SqlClient;

namespace SemiconductorMESDemo
{
    public partial class DataCollectionControl : UserControl
    {
        private Timer _collectTimer;
        private string _currentOrderId;
        private readonly Random _random = new Random();
        // SPC控制限
        private const double UpperLimit = 3.0;
        private const double LowerLimit = 2.0;

        public DataCollectionControl()
        {
            InitializeComponent();
            LoadWorkOrderCombobox();
        }

        // 加载下拉工单
        private void LoadWorkOrderCombobox()
        {
            DataTable dt = SqlHelper.GetDataTable("SELECT OrderID FROM Mes_WorkOrder WHERE Status=1");
            cbWorkOrder.ItemsSource = dt.DefaultView;
            cbWorkOrder.DisplayMemberPath = "OrderID";
            cbWorkOrder.SelectedValuePath = "OrderID";
            if (dt.Rows.Count > 0) cbWorkOrder.SelectedIndex = 0;
        }

        // 刷新采集数据列表
        public void LoadCollectDataList()
        {
            string sql = @"SELECT EqpID as 设备编号,WaferID as 晶圆ID,TestParam as 测试参数,TestValue as 测试值,IsPass as 是否合格,CollectTime as 采集时间 
                           FROM Mes_EquipmentData ORDER BY CollectTime DESC";
            DataTable dt = SqlHelper.GetDataTable(sql);
            dt.Columns["是否合格"].ReadOnly = false;
            foreach (DataRow row in dt.Rows)
            {
                bool pass = bool.Parse(row["是否合格"].ToString());
                row["是否合格"] = pass ? "合格" : "不合格";
            }
            // WPF必须在UI线程更新控件
            Dispatcher.Invoke(() => {
                dgCollectData.ItemsSource = dt.DefaultView;
            });
        }

        // 开始采集
        private void BtnStartCollect_Click(object sender, RoutedEventArgs e)
        {
            _currentOrderId = cbWorkOrder.SelectedValue?.ToString();
            if (string.IsNullOrEmpty(_currentOrderId))
            {
                System.Windows.MessageBox.Show("请先选择一个生产中的工单！");
                return;
            }

            _collectTimer = new Timer(5000); // 每5秒采集一次
            _collectTimer.Elapsed += CollectOneData;
            _collectTimer.AutoReset = true;
            _collectTimer.Start();

            tbStatus.Text = "采集状态：正在采集";
            tbStatus.Foreground = System.Windows.Media.Brushes.Green;
            btnStart.IsEnabled = false;
            btnStop.IsEnabled = true;
            LoadCollectDataList();
        }

        // 单次采集
        private void CollectOneData(object sender, ElapsedEventArgs e)
        {
            // 模拟生成设备数据，真实场景替换为SECS/GEM协议读设备数据即可
            string eqpId = _random.NextDouble() > 0.5 ? "TP001" : "TE001";
            string waferId = $"W{_currentOrderId.Substring(6)}-{_random.Next(1, 101):D3}";
            string dieId = $"D{_random.Next(1, 1000):D4}";
            double testValue = 2.5 + (_random.NextDouble() - 0.5) * 1.2; // 围绕2.5波动，会偶尔超出控制限
            bool isPass = testValue >= LowerLimit && testValue <= UpperLimit;

            // 插入数据库
            string sql = @"INSERT INTO Mes_EquipmentData(EqpID,OrderID,WaferID,DieID,TestParam,TestValue,IsPass) 
                           VALUES(@EqpID,@OrderID,@WaferID,@DieID,@TestParam,@TestValue,@IsPass)";
            SqlHelper.ExecuteNonQuery(sql,
                new SqlParameter("@EqpID", eqpId),
                new SqlParameter("@OrderID", _currentOrderId),
                new SqlParameter("@WaferID", waferId),
                new SqlParameter("@DieID", dieId),
                new SqlParameter("@TestParam", "接触电阻(mΩ)"),
                new SqlParameter("@TestValue", testValue),
                new SqlParameter("@IsPass", isPass)
            );

            // 如果超出SPC控制限，记录异常
            if (!isPass)
            {
                string exceptionSql = @"INSERT INTO Mes_Exception(ExceptionType,RelatedNo,Description) 
                                        VALUES('SPC报警',@OrderID,@Desc)";
                SqlHelper.ExecuteNonQuery(exceptionSql,
                    new SqlParameter("@OrderID", _currentOrderId),
                    new SqlParameter("@Desc", $"接触电阻超出控制限，当前值:{testValue:F2}，控制限({LowerLimit}~{UpperLimit})")
                );
            }

            // 刷新列表
            LoadCollectDataList();
        }

        // 停止采集
        private void BtnStopCollect_Click(object sender, RoutedEventArgs e)
        {
            _collectTimer?.Stop();
            _collectTimer?.Dispose();
            tbStatus.Text = "采集状态：已停止";
            tbStatus.Foreground = System.Windows.Media.Brushes.Red;
            btnStart.IsEnabled = true;
            btnStop.IsEnabled = false;
        }
    }
}
