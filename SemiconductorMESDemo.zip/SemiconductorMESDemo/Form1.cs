﻿using System;
using System.Windows.Forms;

namespace SemiconductorMESDemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void 生产工单管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // 切换ElementHost显示工单控件
            elementHost1.Child = new WorkOrderControl();
        }

        private void 设备数据采集ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            elementHost1.Child = new DataCollectionControl();
        }

        private void 质量追溯ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            elementHost1.Child = new QualityTraceControl();
        }

        private void 异常处理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            elementHost1.Child = new ExceptionManageControl();
        }

        private void 设备数据采集ToolStripMenuItem_Click_1(object sender, EventArgs e)
        {

        }
    }
}
