﻿using System.Data;
using System.Windows.Controls;
using System.Windows;
using SemiconductorMESDemo.Helper;
using System.Data.SqlClient;

namespace SemiconductorMESDemo
{
    public partial class WorkOrderControl : UserControl
    {
        public WorkOrderControl()
        {
            InitializeComponent();
            LoadWorkOrderList();
        }

        // 加载工单列表
        public void LoadWorkOrderList()
        {
            string sql = "SELECT OrderID as 工单号,ProductName as 产品名称,BatchNo as 批次号,[Status] as 状态Int,PlanQty as 计划数,FinishedQty as 完成数,CreateTime as 创建时间 FROM Mes_WorkOrder";
            DataTable dt = SqlHelper.GetDataTable(sql);
            // 添加字符串类型的状态列，和你原来XAML绑定的列名一致
            dt.Columns.Add("状态", typeof(string));

            foreach (DataRow row in dt.Rows)
            {
                int status = (int)row["状态Int"];
                switch (status)
                {
                    case 0:
                        row["状态"] = "待下发";
                        break;
                    case 1:
                        row["状态"] = "生产中";
                        break;
                    case 2:
                        row["状态"] = "已完成";
                        break;
                    case 3:
                        row["状态"] = "已关闭";
                        break;
                    default:
                        row["状态"] = "未知";
                        break;
                }
            }
            // 删除不需要显示的原始int列
            dt.Columns.Remove("状态Int");
            dgWorkOrder.ItemsSource = dt.DefaultView;
        }

        // 刷新
        private void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {
            LoadWorkOrderList();
        }

        // 新建工单
        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            string newOrderId = "WO" + System.DateTime.Now.ToString("yyyyMMddHHmm");
            string sql = @"INSERT INTO Mes_WorkOrder(OrderID,ProductID,ProductName,BatchNo,ProcessRoute,[Status],PlanQty,CreateUser) 
                        VALUES(@OrderID,@ProductID,@ProductName,@BatchNo,@Route,0,50,'admin')";
            SqlHelper.ExecuteNonQuery(sql,
                new SqlParameter("@OrderID", newOrderId),
                new SqlParameter("@ProductID", "P-SEM-002"),
                new SqlParameter("@ProductName", "功率MOS管"),
                new SqlParameter("@BatchNo", "B" + System.DateTime.Now.ToString("yyyyMMdd")),
                new SqlParameter("@Route", "晶圆测试→切割→封装")
            );
            System.Windows.MessageBox.Show("新建工单成功！");
            LoadWorkOrderList();
        }
    }
}
