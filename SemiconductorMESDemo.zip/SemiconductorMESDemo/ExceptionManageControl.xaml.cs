﻿using System.Data;
using System.Windows.Controls;
using System.Windows;
using SemiconductorMESDemo.Helper;
using System.Data.SqlClient;

namespace SemiconductorMESDemo
{
    public partial class ExceptionManageControl : UserControl
    {
        private long _selectedExceptionId = 0;
        public ExceptionManageControl()
        {
            InitializeComponent();
            LoadExceptionList();
        }

        // 加载异常列表
        public void LoadExceptionList()
        {
            string sql = @"SELECT ExceptionID as 异常编号,ExceptionType as 异常类型,RelatedNo as 关联单号,
                          Description as 异常描述,Status as 状态,CreateTime as 创建时间 
                          FROM Mes_Exception ORDER BY CreateTime DESC";
            DataTable dt = SqlHelper.GetDataTable(sql);

            // 状态转文字方便阅读
            dt.Columns["状态"].ReadOnly = false;
            foreach (DataRow row in dt.Rows)
            {
                int status = int.Parse(row["状态"].ToString());
                switch (status)
                {
                    case 0:
                        row["状态"] = "待处理";
                        break;
                    case 1:
                        row["状态"] = "已处理";
                        break;
                    default:
                        row["状态"] = "未知";
                        break;
                }
            }

            // 绑定到表格
            Dispatcher.Invoke(() => {
                dgException.ItemsSource = dt.DefaultView;
            });
        }

        // 刷新按钮
        private void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {
            LoadExceptionList();
            _selectedExceptionId = 0;
            btnProcess.IsEnabled = false;
            tbProcessNote.Clear();
        }

        // 选中表格行，获取要处理的异常ID
        private void dgException_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dgException.SelectedItem is DataRowView row)
            {
                // 只有待处理异常可以处理
                string status = row["状态"].ToString();
                if (status == "待处理")
                {
                    _selectedExceptionId = long.Parse(row["异常编号"].ToString());
                    btnProcess.IsEnabled = true;
                }
                else
                {
                    _selectedExceptionId = 0;
                    btnProcess.IsEnabled = false;
                    System.Windows.MessageBox.Show("该异常已经处理完成");
                }
            }
        }

        // 处理异常按钮逻辑
        private void BtnProcess_Click(object sender, RoutedEventArgs e)
        {
            if (_selectedExceptionId <= 0)
            {
                System.Windows.MessageBox.Show("请先选择一个待处理的异常");
                return;
            }
            string note = tbProcessNote.Text.Trim();
            if (string.IsNullOrEmpty(note))
            {
                System.Windows.MessageBox.Show("请输入处理备注");
                return;
            }

            // 更新异常状态为已处理
            string sql = @"UPDATE Mes_Exception 
                          SET Status=1,ProcessNote=@Note,ProcessTime=GETDATE() 
                          WHERE ExceptionID=@Id";
            int result = SqlHelper.ExecuteNonQuery(sql,
                new SqlParameter("@Note", note),
                new SqlParameter("@Id", _selectedExceptionId)
            );

            if (result > 0)
            {
                System.Windows.MessageBox.Show("异常处理完成");
                LoadExceptionList();
                _selectedExceptionId = 0;
                btnProcess.IsEnabled = false;
                tbProcessNote.Clear();
            }
            else
            {
                System.Windows.MessageBox.Show("处理失败，请重试");
            }
        }
    }
}
