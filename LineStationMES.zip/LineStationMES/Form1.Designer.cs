﻿namespace LineStationMES
{
    partial class MainForm
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label_Sn = new System.Windows.Forms.Label();
            this.txtEngineSN = new System.Windows.Forms.TextBox();
            this.txtTorque = new System.Windows.Forms.TextBox();
            this.txtAngle = new System.Windows.Forms.TextBox();
            this.dgvHistory = new System.Windows.Forms.DataGridView();
            this.btnCollectData = new System.Windows.Forms.Button();
            this.btnQueryHistory = new System.Windows.Forms.Button();
            this.label_Angle = new System.Windows.Forms.Label();
            this.label_Torque = new System.Windows.Forms.Label();
            this.label_StationState = new System.Windows.Forms.Label();
            this.lblState = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHistory)).BeginInit();
            this.SuspendLayout();
            // 
            // label_Sn
            // 
            this.label_Sn.AutoSize = true;
            this.label_Sn.Location = new System.Drawing.Point(30, 30);
            this.label_Sn.Name = "label_Sn";
            this.label_Sn.Size = new System.Drawing.Size(89, 12);
            this.label_Sn.TabIndex = 0;
            this.label_Sn.Text = "发动机SN编号：";
            // 
            // txtEngineSN
            // 
            this.txtEngineSN.Location = new System.Drawing.Point(130, 30);
            this.txtEngineSN.Name = "txtEngineSN";
            this.txtEngineSN.Size = new System.Drawing.Size(200, 21);
            this.txtEngineSN.TabIndex = 1;
            // 
            // txtTorque
            // 
            this.txtTorque.Location = new System.Drawing.Point(130, 70);
            this.txtTorque.Name = "txtTorque";
            this.txtTorque.ReadOnly = true;
            this.txtTorque.Size = new System.Drawing.Size(120, 21);
            this.txtTorque.TabIndex = 2;
            // 
            // txtAngle
            // 
            this.txtAngle.Location = new System.Drawing.Point(130, 110);
            this.txtAngle.Name = "txtAngle";
            this.txtAngle.ReadOnly = true;
            this.txtAngle.Size = new System.Drawing.Size(120, 21);
            this.txtAngle.TabIndex = 3;
            // 
            // dgvHistory
            // 
            this.dgvHistory.AllowUserToAddRows = false;
            this.dgvHistory.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvHistory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHistory.Location = new System.Drawing.Point(30, 200);
            this.dgvHistory.Name = "dgvHistory";
            this.dgvHistory.ReadOnly = true;
            this.dgvHistory.RowTemplate.Height = 23;
            this.dgvHistory.Size = new System.Drawing.Size(720, 230);
            this.dgvHistory.TabIndex = 4;
            // 
            // btnCollectData
            // 
            this.btnCollectData.Location = new System.Drawing.Point(350, 30);
            this.btnCollectData.Name = "btnCollectData";
            this.btnCollectData.Size = new System.Drawing.Size(120, 40);
            this.btnCollectData.TabIndex = 5;
            this.btnCollectData.Text = "采集保存数据";
            this.btnCollectData.UseVisualStyleBackColor = true;
            this.btnCollectData.Click += new System.EventHandler(this.btnCollectData_Click);
            // 
            // btnQueryHistory
            // 
            this.btnQueryHistory.Location = new System.Drawing.Point(350, 80);
            this.btnQueryHistory.Name = "btnQueryHistory";
            this.btnQueryHistory.Size = new System.Drawing.Size(120, 40);
            this.btnQueryHistory.TabIndex = 6;
            this.btnQueryHistory.Text = "查询历史数据";
            this.btnQueryHistory.UseVisualStyleBackColor = true;
            this.btnQueryHistory.Click += new System.EventHandler(this.btnQueryHistory_Click);
            // 
            // label_Angle
            // 
            this.label_Angle.AutoSize = true;
            this.label_Angle.Location = new System.Drawing.Point(30, 110);
            this.label_Angle.Name = "label_Angle";
            this.label_Angle.Size = new System.Drawing.Size(89, 12);
            this.label_Angle.TabIndex = 7;
            this.label_Angle.Text = "拧紧角度(°)：";
            // 
            // label_Torque
            // 
            this.label_Torque.AutoSize = true;
            this.label_Torque.Location = new System.Drawing.Point(30, 70);
            this.label_Torque.Name = "label_Torque";
            this.label_Torque.Size = new System.Drawing.Size(101, 12);
            this.label_Torque.TabIndex = 8;
            this.label_Torque.Text = "当前扭矩(N·m)：";
            // 
            // label_StationState
            // 
            this.label_StationState.AutoSize = true;
            this.label_StationState.Location = new System.Drawing.Point(30, 150);
            this.label_StationState.Name = "label_StationState";
            this.label_StationState.Size = new System.Drawing.Size(89, 12);
            this.label_StationState.TabIndex = 9;
            this.label_StationState.Text = "工位当前状态：";
            // 
            // lblState
            // 
            this.lblState.AutoSize = true;
            this.lblState.Location = new System.Drawing.Point(130, 150);
            this.lblState.Name = "lblState";
            this.lblState.Size = new System.Drawing.Size(29, 12);
            this.lblState.TabIndex = 10;
            this.lblState.Text = "待机";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 461);
            this.Controls.Add(this.lblState);
            this.Controls.Add(this.label_StationState);
            this.Controls.Add(this.label_Torque);
            this.Controls.Add(this.label_Angle);
            this.Controls.Add(this.btnQueryHistory);
            this.Controls.Add(this.btnCollectData);
            this.Controls.Add(this.dgvHistory);
            this.Controls.Add(this.txtAngle);
            this.Controls.Add(this.txtTorque);
            this.Controls.Add(this.txtEngineSN);
            this.Controls.Add(this.label_Sn);
            this.Location = new System.Drawing.Point(30, 30);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "动力总成拧紧工位上位机";
            ((System.ComponentModel.ISupportInitialize)(this.dgvHistory)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_Sn;
        private System.Windows.Forms.TextBox txtEngineSN;
        private System.Windows.Forms.TextBox txtTorque;
        private System.Windows.Forms.TextBox txtAngle;
        private System.Windows.Forms.DataGridView dgvHistory;
        private System.Windows.Forms.Button btnCollectData;
        private System.Windows.Forms.Button btnQueryHistory;
        private System.Windows.Forms.Label label_Angle;
        private System.Windows.Forms.Label label_Torque;
        private System.Windows.Forms.Label label_StationState;
        private System.Windows.Forms.Label lblState;
    }
}

