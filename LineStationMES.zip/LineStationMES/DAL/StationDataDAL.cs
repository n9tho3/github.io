﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace LineStationMES.DAL
{
    // 原生数据访问层，不用第三方框架
    public class StationDataDAL
    {
        // 从配置读取连接字符串，原生写法
        private readonly string connStr = ConfigurationManager.ConnectionStrings["AutomotiveMESConn"].ConnectionString;

        // 插入采集数据，调用存储过程
        public bool AddTighteningData(string engineSn, decimal torque, int angle, bool isOk, string stationNo)
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                SqlCommand cmd = new SqlCommand("sp_AddTighteningData", conn);
                cmd.CommandType = CommandType.StoredProcedure; // 指定调用存储过程，符合岗位要求
                // 添加参数
                cmd.Parameters.AddWithValue("@EngineSN", engineSn);
                cmd.Parameters.AddWithValue("@TorqueValue", torque);
                cmd.Parameters.AddWithValue("@AngleValue", angle);
                cmd.Parameters.AddWithValue("@IsOK", isOk ? 1 : 0);
                cmd.Parameters.AddWithValue("@StationNo", stationNo);

                try
                {
                    conn.Open();
                    return cmd.ExecuteNonQuery() > 0;
                }
                catch (Exception ex)
                {
                    // 这里可以加日志，体现问题诊断能力
                    throw new Exception("数据插入失败：" + ex.Message);
                }
            }
        }

        // 查询历史数据
        public DataTable GetHistoryData(string engineSn)
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                SqlCommand cmd = new SqlCommand("sp_GetHistoryDataBySN", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@EngineSN", engineSn);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                try
                {
                    conn.Open();
                    adapter.Fill(dt);
                    return dt;
                }
                catch (Exception ex)
                {
                    throw new Exception("数据查询失败：" + ex.Message);
                }
            }
        }
    }
}
