﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using System.Windows.Forms;
using System.Net.Http;

namespace LineStationMES
{
    // 放到命名空间下，所有.NET版本都支持，不用改任何东西
    [XmlRoot("StationData")]
    public class ScadaStationData
    {
        public string EngineSN { get; set; }
        public decimal Torque { get; set; }
        public int Angle { get; set; }
        public bool IsQualified { get; set; }
        public string StationNo { get; set; }
        public string UploadTime { get; set; }
    }

    public partial class MainForm : Form
    {
        // 本地数据存储路径，程序运行目录下的data.csv，不用装数据库
        private readonly string _localDataPath = Path.Combine(Application.StartupPath, "tighten_data.csv");
        // 模拟SCADA接口地址，实际对接改成你们现场SCADA的真实地址就行
        private readonly string _scadaApiUrl = "http://scada.yourcompany.com/api/upload";
        // 拧紧工艺标准，这里可以根据你的实际要求改
        private readonly decimal _standardTorqueMin = 28;
        private readonly decimal _standardTorqueMax = 32;
        private readonly int _standardAngleMin = 270;
        private readonly int _standardAngleMax = 330;

        public MainForm()
        {
            InitializeComponent();
            // 程序启动的时候，如果本地文件不存在，就创建表头
            if (!File.Exists(_localDataPath))
            {
                var header = "发动机SN,扭矩(N·m),拧紧角度(°),是否合格,采集时间\n";
                File.WriteAllText(_localDataPath, header, Encoding.UTF8);
            }
            lblState.Text = "待机";
        }

        // 采集保存数据按钮点击事件
        private async void btnCollectData_Click(object sender, EventArgs e)
        {
            // 1. 校验输入
            if (string.IsNullOrWhiteSpace(txtEngineSN.Text))
            {
                MessageBox.Show("请输入或扫描发动机SN编号！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (string.IsNullOrWhiteSpace(txtTorque.Text) || string.IsNullOrWhiteSpace(txtAngle.Text))
            {
                MessageBox.Show("扭矩和角度数据不能为空！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // 转成数值，判断是否是合法数字
            if (!decimal.TryParse(txtTorque.Text.Trim(), out decimal torque))
            {
                MessageBox.Show("扭矩格式不正确，请输入数字！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (!int.TryParse(txtAngle.Text.Trim(), out int angle))
            {
                MessageBox.Show("角度格式不正确，请输入整数！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // 2. 工艺合格判定
            bool isQualified = torque >= _standardTorqueMin
                            && torque <= _standardTorqueMax
                            && angle >= _standardAngleMin
                            && angle <= _standardAngleMax;

            // 3. 先存本地，工业上位机必须本地缓存，防止断网丢数据
            string line = $"{txtEngineSN.Text.Trim()},{torque},{angle},{isQualified},{DateTime.Now:yyyy-MM-dd HH:mm:ss}\n";
            File.AppendAllText(_localDataPath, line, Encoding.UTF8);

            // 4. 上传到SCADA
            lblState.Text = "正在上传";
            bool uploadResult = await UploadDataToScada(txtEngineSN.Text.Trim(), torque, angle, isQualified, "TIGHTEN_01");

            if (uploadResult)
            {
                lblState.Text = isQualified ? "完成合格" : "完成不合格";
                MessageBox.Show($"数据采集完成，结果：{(isQualified ? "合格" : "不合格")}，已上传SCADA", "提示");
            }
            else
            {
                lblState.Text = "本地存储成功，上传失败";
                MessageBox.Show($"网络异常，数据已保存在本地，稍后会自动补传", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            // 采集完成后自动刷新历史数据
            QueryHistoryData(txtEngineSN.Text.Trim());
        }

        // 查询历史数据按钮点击事件
        private void btnQueryHistory_Click(object sender, EventArgs e)
        {
            string sn = txtEngineSN.Text.Trim();
            if (string.IsNullOrWhiteSpace(sn))
            {
                MessageBox.Show("请先输入要查询的发动机SN编号！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            QueryHistoryData(sn);
        }

        // 查询指定SN的历史数据，绑定到表格显示
        private void QueryHistoryData(string sn)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("发动机SN");
            dt.Columns.Add("扭矩(N·m)");
            dt.Columns.Add("拧紧角度(°)");
            dt.Columns.Add("是否合格");
            dt.Columns.Add("采集时间");

            // 读取本地csv，过滤对应SN的数据
            var allLines = File.ReadAllLines(_localDataPath, Encoding.UTF8);
            // 跳过第一行表头
            for (int i = 1; i < allLines.Length; i++)
            {
                if (string.IsNullOrWhiteSpace(allLines[i])) continue;
                var parts = allLines[i].Split(',');
                if (parts[0].Equals(sn, StringComparison.OrdinalIgnoreCase))
                {
                    DataRow row = dt.NewRow();
                    row[0] = parts[0];
                    row[1] = parts[1];
                    row[2] = parts[2];
                    row[3] = bool.Parse(parts[4]) ? "合格" : "不合格";
                    row[4] = parts[5];
                    dt.Rows.Add(row);
                }
            }

            // 绑定到DataGridView显示
            dgvHistory.DataSource = dt;
        }

        // 原生XML版本上传SCADA，完全不用第三方包
        private async System.Threading.Tasks.Task<bool> UploadDataToScada(string sn, decimal torque, int angle, bool isOk, string stationNo)
        {
            try
            {
                // 构造数据
                var data = new ScadaStationData
                {
                    EngineSN = sn,
                    Torque = torque,
                    Angle = angle,
                    IsQualified = isOk,
                    StationNo = stationNo,
                    UploadTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                };

                // .NET原生XML序列化，全程不用第三方
                string xml;
                using (var writer = new StringWriter())
                {
                    var serializer = new XmlSerializer(typeof(ScadaStationData));
                    serializer.Serialize(writer, data);
                    xml = writer.ToString();
                }

                using (HttpClient client = new HttpClient())
                {
                    client.Timeout = TimeSpan.FromSeconds(10);
                    var content = new StringContent(xml, Encoding.UTF8, "application/xml");
                    var response = await client.PostAsync(_scadaApiUrl, content);
                    return response.IsSuccessStatusCode;
                }
            }
            catch
            {
                return false;
            }
        }
    }
}
