﻿using NICtrl.SGList;

namespace NICtrl
{
    public class SignalGenerator
    {

        SG sg;
        string[] SGList={ "Keysight", "RohdeandSchwarz" };

        public SignalGenerator(string ip)
        {
            NI nI=new NI(ip);
            int x=0, y=0;
            nI.Write("*IND");
            string str=nI.ReadString();
            foreach (string s in SGList)
            {
                bool b= str.IndexOf(s,StringComparison.OrdinalIgnoreCase)>=0;//是否支持品牌设备
                b=str.IndexOf("signalgenerator", StringComparison.OrdinalIgnoreCase)>= 0;
                if (b)
                {
                    y = x;
                }
                x++;
            }
            switch (y)
            {
                case 1 :sg=new Keysight(nI); break;
                case 2 :sg = new RohdeandSchwarz(nI); break;
                default:sg = new SG(nI);
                    break;
            }
        }
        public string FREQ(string s) 
        {
           return sg.FREQ(s);
        }
        public void Write(string s)
        {
            sg.Write(s);
        }
        public string ReadString()
        {
            return sg.ReadString();
        }
    }
}
