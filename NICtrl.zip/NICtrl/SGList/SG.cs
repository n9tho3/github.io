﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NICtrl.SGList
{
    internal class SG : MSbase
    {
        NI SGNI;
        public SG(NI NI):base( NI ) { SGNI = NI; }

        public virtual string FREQ(string cmd) { return ""; }
    }
}
