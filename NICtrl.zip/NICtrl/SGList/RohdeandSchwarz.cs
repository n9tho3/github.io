﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NICtrl.SGList
{
    internal class RohdeandSchwarz:SG
    {
        NI thisNI;
        public RohdeandSchwarz(NI ni):base(ni) { thisNI = ni;}
        public override string FREQ(string cmd)
        {
            string str = "设置仪表数值" + cmd;
            thisNI.Write(str);
            do
            {
                thisNI.Write("查询仪表FREQ数值");
                str = thisNI.ReadString();
            } while (cmd != str);
            return cmd;
        }


    }
}
