﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NICtrl.SAList
{
    internal class RohdeandSchwarz:SA
    {
        NI thisNI;
        public RohdeandSchwarz(NI NI) : base(NI) { thisNI = NI; }
        
        public override string FREQ(string cmd)//设置中心频率；
        {   
            string str = "SENS:FREQ:CENT " + cmd;
            thisNI.Write(str);
            do
            {   
                thisNI.Write("SENS:FREQ:CENT?");
                str = thisNI.ReadString();
            } while (cmd != str);//查询频率是否设置成功
            return cmd;
        }

        public override string dbm(string cmd)
        {
            string str = ":DISPlay:TRACe:Y:RLEVel " + cmd;
            thisNI.Write(str);
            do 
            {

            }while (cmd != str);

            return thisNI.ReadString();
        }
    }
}
