﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NICtrl.SAList
{
    internal class SA:MSbase
    {
        NI myNI;
        public SA(NI nI):base(nI) { myNI = nI; }
        public virtual string FREQ(string cmd) { return ""; }
        public virtual string dbm(string cmd) { return ""; }

    }
}
