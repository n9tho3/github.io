﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NICtrl.SAList;

namespace NICtrl
{
    internal class SignalAnalyzer
    {
        SA sa;
        string[] SAList = { "Keysight", "RohdeandSchwarz" };
        public SignalAnalyzer(string ip)
        {
            NI nI = new NI(ip);
            int x = 0, y = 0;
            nI.Write("*IND");
            string str = nI.ReadString();//获取设备名称
            foreach (string s in SAList)//对支持设备列表进行循环判断，判断设备是否在列表中，获取设备
            {
                bool b = str.IndexOf(s, StringComparison.OrdinalIgnoreCase) >= 0;//是否支持品牌设备
                b = str.IndexOf("signalgenerator", StringComparison.OrdinalIgnoreCase) >= 0;
                if (b)
                {
                    y = x;
                }
                x++;
            }
            switch (y)
            {
                case 1: sa = new Keysight(nI); break;
                case 2: sa = new RohdeandSchwarz(nI); break;
                default:
                    sa = new SA(nI);
                    break;
            }
        }
        public void Write(string str) { sa.Write(str); }
    }
}
