﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NICtrl
{
    //此类库包含所有NI设备的通用命令
    class MSbase
    {
        NI MSNI;
        public MSbase( NI nI) { MSNI = nI; }
        public void Write(string cmd)//写入命令
        {
            MSNI.Write(cmd);
        }
        public string ReadString()//读取命令
        {
            return MSNI.ReadString();
        }
        public string IDN()
        {
            Write("IDN");
            return ReadString();
        }
    }
}
