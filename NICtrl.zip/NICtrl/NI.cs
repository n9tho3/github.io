﻿using Ivi.Visa;
using NationalInstruments.Visa;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace NICtrl
{   //对NI功能进行封装整合
    internal class NI
    {
        ResourceManager resourceManager;
        MessageBasedSession messageBasedSession;
        public NI(string ip) 
        { 
            messageBasedSession = (MessageBasedSession)resourceManager.Open(ip); 
        }

        public void Write(string cmd) //写入命令
        {
            messageBasedSession.RawIO .Write(cmd);
        }
        public string ReadString()//读取回执
        {
            return messageBasedSession.RawIO.ReadString();
        }


        
    }
}
