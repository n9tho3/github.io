﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace Print3DHostDemo.Models;
public partial class PrintTask : ObservableObject
{
    [ObservableProperty]
    private string _taskName;

    [ObservableProperty]
    private string _status = "待打印";

    public DateTime CreateTime { get; set; } = DateTime.Now;
}
