﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace Print3DHostDemo.Models;
// 设备状态模型：存温度、进度、连接状态这些信息
public partial class DeviceStatus : ObservableObject
{
    [ObservableProperty]
    private bool _isConnected;

    [ObservableProperty]
    private double _currentTemperature;

    [ObservableProperty]
    private int _printProgress;

    [ObservableProperty]
    private string _currentState = "未连接";
}
