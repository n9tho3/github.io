﻿using System.Windows;
using Print3DHostDemo.ViewModels;

namespace Print3DHostDemo.Views
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            // 后台手动绑定ViewModel，比XAML实例化更稳妥
            this.DataContext = new MainViewModel();
        }
    }
}
