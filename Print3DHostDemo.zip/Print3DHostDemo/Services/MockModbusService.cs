﻿using Print3DHostDemo.Models;

namespace Print3DHostDemo.Services;
// 模拟Modbus通信：不用接真实硬件也能测试效果
public class MockModbusService : IModbusCommunication
{
    private bool _isConnected;
    private readonly Random _random = new();

    public Task<bool> ConnectAsync(string ip, int port)
    {
        _isConnected = true;
        return Task.FromResult(true);
    }

    public Task DisconnectAsync()
    {
        _isConnected = false;
        return Task.CompletedTask;
    }

    public Task<DeviceStatus> ReadDeviceStatusAsync()
    {
        if (!_isConnected)
        {
            return Task.FromResult(new DeviceStatus { IsConnected = false, CurrentState = "未连接" });
        }
        // 模拟返回随机的设备数据，真实开发这里改成读硬件寄存器
        return Task.FromResult(new DeviceStatus
        {
            IsConnected = true,
            CurrentTemperature = _random.Next(20, 220),
            PrintProgress = _random.Next(0, 100),
            CurrentState = _random.Next(0, 100) > 90 ? "打印完成" :
                          _random.Next(0, 100) > 50 ? "正在打印" : "待机"
        });
    }

    public Task<bool> SendPrintCommandAsync(string command)
    {
        if (!_isConnected) return Task.FromResult(false);
        // 模拟打印日志，真实开发这里改成发指令给下位机
        Console.WriteLine($"下发打印指令：{command}");
        return Task.FromResult(true);
    }
}
