﻿using Print3DHostDemo.Models;

namespace Print3DHostDemo.Services;
// 通信接口：定义和下位机通信的标准，方便后续替换真实硬件
public interface IModbusCommunication
{
    // 连接设备
    Task<bool> ConnectAsync(string ip, int port);
    // 断开连接
    Task DisconnectAsync();
    // 读取设备状态
    Task<DeviceStatus> ReadDeviceStatusAsync();
    // 下发打印指令
    Task<bool> SendPrintCommandAsync(string command);
}
