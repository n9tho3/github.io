﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Input;

namespace Print3DHostDemo.ViewModels
{
    // 这里去掉重复声明，完整单类实现
    public class MainViewModel : INotifyPropertyChanged
    {
        #region 基础属性通知（实现绑定更新）
        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        #endregion

        #region 界面绑定属性
        // 设备状态
        private string _printStatus = "未连接";
        public string PrintStatus
        {
            get => _printStatus;
            set { _printStatus = value; OnPropertyChanged(); }
        }

        // 喷嘴温度
        private double _nozzleTemp = 200;
        public double NozzleTemp
        {
            get => _nozzleTemp;
            set { _nozzleTemp = value; OnPropertyChanged(); }
        }

        // 热床温度
        private double _bedTemp = 60;
        public double BedTemp
        {
            get => _bedTemp;
            set { _bedTemp = value; OnPropertyChanged(); }
        }

        // 打印速度
        private double _printSpeed = 60;
        public double PrintSpeed
        {
            get => _printSpeed;
            set { _printSpeed = value; OnPropertyChanged(); }
        }

        // 打印进度
        private double _printProgress = 0;
        public double PrintProgress
        {
            get => _printProgress;
            set { _printProgress = value; OnPropertyChanged(); }
        }

        // 运行日志
        private string _runLog = "系统启动完成，等待设备连接...\r\n";
        public string RunLog
        {
            get => _runLog;
            set { _runLog = value; OnPropertyChanged(); }
        }

        // 串口列表
        public ObservableCollection<string> PortList { get; set; } = new ObservableCollection<string>();
        private string _selectedPort;
        public string SelectedPort
        {
            get => _selectedPort;
            set { _selectedPort = value; OnPropertyChanged(); }
        }

        // 连接状态
        private bool _isConnected;
        public bool IsConnected
        {
            get => _isConnected;
            set { _isConnected = value; OnPropertyChanged(); }
        }
        #endregion

        #region 按钮命令绑定
        public ICommand ConnectCommand { get; }
        public ICommand StartPrintCommand { get; }
        public ICommand PausePrintCommand { get; }
        public ICommand StopPrintCommand { get; }

        // 通用命令实现，不用额外写文件
        public class RelayCommand : ICommand
        {
            private readonly Action _execute;
            public event EventHandler CanExecuteChanged;
            public bool CanExecute(object parameter) => true;
            public void Execute(object parameter) => _execute?.Invoke();
            public RelayCommand(Action execute) => _execute = execute;
        }

        // 构造函数：初始化所有数据和命令
        public MainViewModel()
        {
            // 初始化示例串口列表，实际项目改成你的串口扫描逻辑即可
            PortList.Add("COM1");
            PortList.Add("COM2");
            PortList.Add("COM3");
            SelectedPort = PortList[0];

            // 绑定按钮方法
            ConnectCommand = new RelayCommand(ToggleConnect);
            StartPrintCommand = new RelayCommand(StartPrint);
            PausePrintCommand = new RelayCommand(PausePrint);
            StopPrintCommand = new RelayCommand(StopPrint);
        }
        #endregion

        #region 基础业务逻辑（你可以替换成自己的真实3D打印逻辑）
        /// <summary>切换设备连接状态</summary>
        private void ToggleConnect()
        {
            if (!IsConnected)
            {
                IsConnected = true;
                PrintStatus = "已连接，待机";
                RunLog += $"[{DateTime.Now:HH:mm:ss}] 成功连接设备 {SelectedPort}\r\n";
            }
            else
            {
                IsConnected = false;
                PrintStatus = "已断开";
                RunLog += $"[{DateTime.Now:HH:mm:ss}] 断开设备连接\r\n";
            }
        }

        /// <summary>开始打印</summary>
        private void StartPrint()
        {
            if (!IsConnected)
            {
                RunLog += $"[{DateTime.Now:HH:mm:ss}] 错误：请先连接设备\r\n";
                return;
            }
            PrintStatus = "打印中";
            RunLog += $"[{DateTime.Now:HH:mm:ss}] 开始打印，喷嘴温度：{NozzleTemp:F0}℃，热床温度：{BedTemp:F0}℃\r\n";
            PrintProgress = 0.3; // 示例进度，实际替换成真实进度即可
        }

        /// <summary>暂停打印</summary>
        private void PausePrint()
        {
            PrintStatus = "已暂停";
            RunLog += $"[{DateTime.Now:HH:mm:ss}] 打印已暂停\r\n";
        }

        /// <summary>停止打印</summary>
        private void StopPrint()
        {
            PrintStatus = "已停止";
            PrintProgress = 0;
            RunLog += $"[{DateTime.Now:HH:mm:ss}] 打印已停止\r\n";
        }
        #endregion
    }
}
