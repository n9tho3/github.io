﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Print3DHostDemo.Models;
using Print3DHostDemo.Services;
using System.Collections.ObjectModel;
using System.Windows;

namespace Print3DHostDemo.ViewModels;
public partial class TaskManageViewModel : ObservableObject
{
    private readonly IModbusCommunication _modbus;
    // 任务列表，绑定到界面显示
    public ObservableCollection<PrintTask> PrintTasks { get; set; } = new();

    [ObservableProperty]
    private string _newTaskName;

    public TaskManageViewModel(IModbusCommunication modbus)
    {
        _modbus = modbus;
        // 初始化加两个示例任务
        PrintTasks.Add(new PrintTask { TaskName = "齿科模型001", Status = "打印完成" });
        PrintTasks.Add(new PrintTask { TaskName = "骨科支架002", Status = "待打印" });
    }

    // 新建打印任务
    [RelayCommand]
    private void AddTask()
    {
        if (string.IsNullOrWhiteSpace(_newTaskName))
        {
            MessageBox.Show("请输入任务名称");
            return;
        }
        PrintTasks.Add(new PrintTask { TaskName = _newTaskName });
        _newTaskName = string.Empty;
    }

    // 开始打印选中任务
    [RelayCommand]
    private async Task StartPrint(PrintTask task)
    {
        if (task == null) return;
        bool result = await _modbus.SendPrintCommandAsync($"START_PRINT:{task.TaskName}");
        if (result)
        {
            task.Status = "正在打印";
            MessageBox.Show($"已开始打印：{task.TaskName}");
        }
        else
        {
            MessageBox.Show("打印失败，设备未连接");
        }
    }

    // 删除任务
    [RelayCommand]
    private void DeleteTask(PrintTask task)
    {
        if (task != null)
        {
            PrintTasks.Remove(task);
        }
    }
}
