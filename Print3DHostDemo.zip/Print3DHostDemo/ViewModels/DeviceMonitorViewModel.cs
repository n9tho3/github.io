﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Print3DHostDemo.Models;
using Print3DHostDemo.Services;
using System.Windows;

namespace Print3DHostDemo.ViewModels;
public partial class DeviceMonitorViewModel : ObservableObject
{
    private readonly IModbusCommunication _modbus;
    // 这里声明的是变量_deviceStatus，[ObservableProperty]会自动生成公开的DeviceStatus属性
    [ObservableProperty]
    private DeviceStatus _deviceStatus = new();

    public DeviceMonitorViewModel(IModbusCommunication modbus)
    {
        _modbus = modbus;
    }

    [RelayCommand]
    private async Task RefreshStatus()
    {
        // 这里用自动生成的DeviceStatus（大写D开头，是变量不是类型）
        _deviceStatus = await _modbus.ReadDeviceStatusAsync();
        if (!_deviceStatus.IsConnected)
        {
            MessageBox.Show("设备未连接，请先连接设备");
        }
    }
}
