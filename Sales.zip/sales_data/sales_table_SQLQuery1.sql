create database sales
on
(name ='sales_Data',
filename = 'D:\sqldata\sales_Data.MDF',
SIZE =2,
filegrowth=10%)
log on (NAME =N'sales_Log',
filename=N'D:\sqldata\sales_Log.LDF',
size=1,
filegrowth=10%)
go



use sales
GO
--������
create table seller(
seleID char(3) not null PRIMARY KEY,
Salename char (8) not null,
Sex char (2) null,
Birthady datetime null,
HireDate datetime null,
Address char (60) null,
Telephone char(13) null,
Notes char (200) null
)
go
create table category(
categoryID int not null primary key,
CategoryName nvarchar (15) null,
Description nvarchar (200) null
)
go
create table Customer (
CustomerID char (3) not null primary key,
CompanyName char (60)not null,
ConnectName char (8) null,
Address char (40) null,
ZipCode char (10) null,
Telephone char (13) null
)
go
Create table OrderDetail(
OrderID int Not null,
ProductID char (6) not null,
Quantity int null ,
TotalPrice money null,
constraint PK_OrderDetail Primary key (OrderID,ProductID)
)
go
create table Orders (
PrderID int not null primary key,
CustomerID char (3) not null,
SaleID char (3) not null,
OrderDate datetime null,
Notes char (200) null
)
go
create table Product(
ProductID char (6) not null primary key,
ProductName varchar (40) not null,
CategoryID int null,
Price money null,
stocks smallint null
)
go
create table TotalSale(
SaleID char(3) not null primary key,
Total money null
)
go
create table dbo_User(
ID int not null primary key,
UserName nvarchar (20) null,
Password nvarchar (8) null
)
go