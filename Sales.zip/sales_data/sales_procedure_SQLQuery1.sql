--��Category����������
create procedure InsertCategory
@CategoryID int,
@CategoryName nvarchar(15),
@Description nvarchar(200)
as
delete from Category where CategoryID=@CategoryID
insert into Category (CategoryID,CategoryName,Description)
values(@CategoryID,@CategoryName,@Description)
go
--����Category������
create procedure UpdateCategory
@CategoryID int,
@CategoryName nvarchar(15),
@Description nvarchar(200)
as
update Category
Set CategoryName=@CategoryName,Description=@Description
where CategoryID=@CategoryID
go
--ɾ��Category��������
create procedure DeleteCategory
@CategoryID int
as
delete from Category where CategoryID=CategoryID
go
--��Customer����������
create procedure InsertCustomer
@CustomerID char(3),
@CompanyName char(60),
@ConnectName char(8),
@Address char(40),
@ZipCode char(10),
@Telephone char(13)
as
delete from Customer where CustomerID=@CustomerID
insert into Customer
(CustomerID,CompanyName,ConnectName,Address,Zipcode,Telephone)values
(@CustomerID,@CompanyName,@ConnectName,@Address,@ZipCode,@Telephone)
------------------------------------------------err^|
go
--����Customer ��������
create procedure UpdateCustomer
@CustomerID char(3),
@CompanyName char(60),
@ConnectName char(8),
@Address char(40),
@ZipCode char(10),
@Telephone char(13)
as
update Customer
set CompanyName=@CompanyName,ConnectName=@ConnectName,Address=@Address,
Zipcode=@ZipCode,Telephone=@Telephone
where CustomerID=@CustomerID
go
--ɾ��Customer��������
create procedure DeleteCustomer
@CustomerID char(3)
as
delete from Customer where CustomerID=@CustomerID
go
--��Ordersr����������
create procedure InsertOrders
@OrderID int,
@CustomerID char(3),
@SaleID char(3),
@OrderDate datetime,
@Notes char(200)
as
delete from Orders where OrderID=@OrderID
insert into Orders
(OrderID, CustomerID,SaleID,OrderDate,Notes)
values(@OrderID,@CustomerID,@SaleID,@OrderDate,@Notes)
go
--����Orders��������
create procedure UpdateOrders
@OrderID int,
@CustomerID char(3),
@SaleID char(3),
@OrderDate datetime,
@Notes char(200)
as
update Orders
set CustomerID=@CustomerID,SaleID=@SaleID,OrderDate=@OrderDate
where OrderID=@OrderID
go
--ɾ��Orders��������
create procedure DeleteOrders
@OrderID int
as
delete from Orders Where OrderID=@OrderID
delete from OrderDetail where OrderID=@OrderID
go
--��OrderDetail����������
create procedure InsertOrdersDetails
@OrderID int,
@ProductID char(6),
@Quantity int,
@TotalPrice money
as
insert into OrderDetail
(OrderID,ProductID,Quantity,TotalPrice)
values(@OrderID,@ProductID,@Quantity,@TotalPrice)
update Product 
set stocks=stocks-@Quantity
where ProductID=@ProductID
go
--����Order Detail��������
create procedure UpdateOrdersDetails
@OrderID int,
@ProductID char(6),
@Quantity int,
@TotalPrice money
as
Update OrderDetail
set ProductID=@ProductID,Quantity=@Quantity,TotalPrice=@TotalPrice
where OrderID=@OrderID
go
--ɾ��OrderDetail��������
create procedure DeleteOrdersDetails
@OrderID int
as
Delete from OrderDetail where OrderID=@OrderID
go
--��Product����������
create procedure InsertProduct 
@ProductID char(6),
@ProductName varchar(40),
@CategoryID int,
@Price money,
@stocks smallint
as
delete from Product where ProductID=@ProductID
insert into Product
(ProductID,ProductName,CategoryID,Price,stocks)
values(@ProductID,@ProductName,@CategoryID,@Price,@stocks)
go
--����Product��������
create procedure UpdateProduct
@ProductID char(6),
@ProductName varchar(40),
@CategoryID int,
@Price money,
@stocks smallint
as
update Product
set ProductName=@ProductName,CategoryID=CategoryID,
Price=@price, stocks=@stocks
where ProductID=@ProductID
go
--ɾ��Product������
create procedure DeleteProduct
@ProductID char(6)
as
delete from Product where ProductID=@ProductID
go
--��Seller����������
create procedure InsertSeller
@SaleID char(3),
@Salename char(8),
@Sex char(2),
@Birthday datetime,
@HireDate datetime,
@Address char(60),
@Telephone char(13),
@Notes char(200)
as 
delete from Seller where SaleID=@SaleID
insert into Seller
(SaleID,Salename,Sex,Birthday,HireDate,Address,Telephone,Notes)values(@SaleID,
@Salename,@Sex,@Birthday,@HireDate,@Address,@Telephone,@Notes)
go
--����Seller��������
create procedure UpdateSeller
@SaleID char(3),
@Salename char(8),
@Sex char(2),
@Birthday datetime,
@HireDate datetime,
@Address char(60),
@Telephone char(13),
@Notes char(200)
as
Update Seller
set Salename=@Salename,Sex=@Sex,Birthday=@Birthday,HireDate=@HireDate,
Address=@Address,Telephone=@Telephone,Notes=@Notes
where SaleID=@SaleID
go
--ɾ��Seller��������
create procedure DeleteSeller
@SaleID char(3)
as
delete from Seller
Where SaleID=@SaleID
go
