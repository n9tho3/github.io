﻿namespace Sales
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnQuery = new System.Windows.Forms.Button();
			this.txtNo1 = new System.Windows.Forms.TextBox();
			this.txtNo2 = new System.Windows.Forms.TextBox();
			this.dtpDate1 = new System.Windows.Forms.DateTimePicker();
			this.dtpDate2 = new System.Windows.Forms.DateTimePicker();
			this.grdQuery = new System.Windows.Forms.DataGridView();
			this.button1 = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.grdQuery)).BeginInit();
			this.SuspendLayout();
			// 
			// btnQuery
			// 
			this.btnQuery.Location = new System.Drawing.Point(657, 39);
			this.btnQuery.Name = "btnQuery";
			this.btnQuery.Size = new System.Drawing.Size(75, 23);
			this.btnQuery.TabIndex = 0;
			this.btnQuery.Text = "查询";
			this.btnQuery.UseVisualStyleBackColor = true;
			this.btnQuery.Click += new System.EventHandler(this.btnQuery_Click);
			// 
			// txtNo1
			// 
			this.txtNo1.Location = new System.Drawing.Point(89, 41);
			this.txtNo1.Name = "txtNo1";
			this.txtNo1.Size = new System.Drawing.Size(196, 21);
			this.txtNo1.TabIndex = 1;
			// 
			// txtNo2
			// 
			this.txtNo2.Location = new System.Drawing.Point(385, 41);
			this.txtNo2.Name = "txtNo2";
			this.txtNo2.Size = new System.Drawing.Size(200, 21);
			this.txtNo2.TabIndex = 2;
			// 
			// dtpDate1
			// 
			this.dtpDate1.Location = new System.Drawing.Point(89, 107);
			this.dtpDate1.Name = "dtpDate1";
			this.dtpDate1.Size = new System.Drawing.Size(196, 21);
			this.dtpDate1.TabIndex = 3;
			// 
			// dtpDate2
			// 
			this.dtpDate2.Location = new System.Drawing.Point(385, 106);
			this.dtpDate2.Name = "dtpDate2";
			this.dtpDate2.Size = new System.Drawing.Size(200, 21);
			this.dtpDate2.TabIndex = 4;
			// 
			// grdQuery
			// 
			this.grdQuery.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.grdQuery.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.grdQuery.Location = new System.Drawing.Point(12, 164);
			this.grdQuery.Name = "grdQuery";
			this.grdQuery.RowTemplate.Height = 23;
			this.grdQuery.Size = new System.Drawing.Size(846, 236);
			this.grdQuery.TabIndex = 5;
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(657, 106);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(75, 23);
			this.button1.TabIndex = 6;
			this.button1.Text = "取消";
			this.button1.UseVisualStyleBackColor = true;
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(870, 421);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.grdQuery);
			this.Controls.Add(this.dtpDate2);
			this.Controls.Add(this.dtpDate1);
			this.Controls.Add(this.txtNo2);
			this.Controls.Add(this.txtNo1);
			this.Controls.Add(this.btnQuery);
			this.Name = "Form1";
			this.Text = "Form1";
			((System.ComponentModel.ISupportInitialize)(this.grdQuery)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button btnQuery;
		private System.Windows.Forms.TextBox txtNo1;
		private System.Windows.Forms.TextBox txtNo2;
		private System.Windows.Forms.DateTimePicker dtpDate1;
		private System.Windows.Forms.DateTimePicker dtpDate2;
		private System.Windows.Forms.DataGridView grdQuery;
		private System.Windows.Forms.Button button1;
	}
}