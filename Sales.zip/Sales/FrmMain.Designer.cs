﻿namespace Sales
{
	partial class FrmMain
	{
		/// <summary>
		/// 必需的设计器变量。
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 清理所有正在使用的资源。
		/// </summary>
		/// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows 窗体设计器生成的代码

		/// <summary>
		/// 设计器支持所需的方法 - 不要修改
		/// 使用代码编辑器修改此方法的内容。
		/// </summary>
		private void InitializeComponent()
		{
			this.menuStrip1 = new System.Windows.Forms.MenuStrip();
			this.基本信息设置ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.销售员信息ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.客户信息ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.产品信息ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.产品种类信息ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.销售信息管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.帮助ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.menuStrip1.SuspendLayout();
			this.SuspendLayout();
			// 
			// menuStrip1
			// 
			this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.基本信息设置ToolStripMenuItem,
            this.销售信息管理ToolStripMenuItem,
            this.帮助ToolStripMenuItem});
			this.menuStrip1.Location = new System.Drawing.Point(0, 0);
			this.menuStrip1.Name = "menuStrip1";
			this.menuStrip1.Size = new System.Drawing.Size(938, 25);
			this.menuStrip1.TabIndex = 0;
			this.menuStrip1.Text = "menuStrip1";
			this.menuStrip1.Click += new System.EventHandler(this.menuStrip1_Click);
			// 
			// 基本信息设置ToolStripMenuItem
			// 
			this.基本信息设置ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.销售员信息ToolStripMenuItem,
            this.客户信息ToolStripMenuItem,
            this.产品信息ToolStripMenuItem,
            this.产品种类信息ToolStripMenuItem});
			this.基本信息设置ToolStripMenuItem.Name = "基本信息设置ToolStripMenuItem";
			this.基本信息设置ToolStripMenuItem.Size = new System.Drawing.Size(92, 21);
			this.基本信息设置ToolStripMenuItem.Text = "基本信息设置";
			// 
			// 销售员信息ToolStripMenuItem
			// 
			this.销售员信息ToolStripMenuItem.Name = "销售员信息ToolStripMenuItem";
			this.销售员信息ToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
			this.销售员信息ToolStripMenuItem.Text = "销售员信息";
			this.销售员信息ToolStripMenuItem.Click += new System.EventHandler(this.销售员信息ToolStripMenuItem_Click);
			// 
			// 客户信息ToolStripMenuItem
			// 
			this.客户信息ToolStripMenuItem.Name = "客户信息ToolStripMenuItem";
			this.客户信息ToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
			this.客户信息ToolStripMenuItem.Text = "客户信息";
			// 
			// 产品信息ToolStripMenuItem
			// 
			this.产品信息ToolStripMenuItem.Name = "产品信息ToolStripMenuItem";
			this.产品信息ToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
			this.产品信息ToolStripMenuItem.Text = "产品信息";
			// 
			// 产品种类信息ToolStripMenuItem
			// 
			this.产品种类信息ToolStripMenuItem.Name = "产品种类信息ToolStripMenuItem";
			this.产品种类信息ToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
			this.产品种类信息ToolStripMenuItem.Text = "产品种类信息";
			// 
			// 销售信息管理ToolStripMenuItem
			// 
			this.销售信息管理ToolStripMenuItem.Name = "销售信息管理ToolStripMenuItem";
			this.销售信息管理ToolStripMenuItem.Size = new System.Drawing.Size(92, 21);
			this.销售信息管理ToolStripMenuItem.Text = "销售信息管理";
			// 
			// 帮助ToolStripMenuItem
			// 
			this.帮助ToolStripMenuItem.Name = "帮助ToolStripMenuItem";
			this.帮助ToolStripMenuItem.Size = new System.Drawing.Size(44, 21);
			this.帮助ToolStripMenuItem.Text = "帮助";
			// 
			// FrmMain
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(938, 557);
			this.Controls.Add(this.menuStrip1);
			this.MainMenuStrip = this.menuStrip1;
			this.Name = "FrmMain";
			this.Text = "销售管理系统";
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmMain_FormClosing);
			this.menuStrip1.ResumeLayout(false);
			this.menuStrip1.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.MenuStrip menuStrip1;
		private System.Windows.Forms.ToolStripMenuItem 基本信息设置ToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem 销售信息管理ToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem 帮助ToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem 销售员信息ToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem 客户信息ToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem 产品信息ToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem 产品种类信息ToolStripMenuItem;
	}
}

