﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sales
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		//
		DataView myDataView;
		private void btnQuery_Click(object sender, EventArgs e)
		{
			string strSQL = "select*From F_OrderInfoByID('" + 
				(txtNo1.Text == "" ? "00000" : txtNo1.Text) + "','" 
				+ (txtNo2.Text == "" ? "99999" : txtNo2.Text) + "','" 
				+ dtpDate1.Value.ToShortDateString() + "','" + dtpDate2.Value.ToShortDateString() + "') Order by OrderID";

			DataBase db = new DataBase();
			myDataView=db.RunSelectSQL(strSQL);
			grdQuery.DataSource=null;

		}
	}
}
