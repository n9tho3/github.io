﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SqlClient;
using System.Data;

namespace Sales
{
	 class DataBase
	{
		string server = "";
		string database = "";
		string uid = "";
		string pwd = "";
		private string strCon= "server=LAPTOP-DB97AJ1R;database=sales;Integrated security=sspi";
		//com 作为命令对象执行SQL语句 con实现数据库连接
		
		private SqlConnection con;
		public SqlConnection Con
		{
			get { return con; }
			set { con = value; }
		}
		private SqlCommand com;
		public SqlCommand Com
		{
			get { return com; }
			set { com = value; }
		}


		//连接并打开数据库
		public void Open()
		{
			if (con == null)
			{
				con = new SqlConnection(strCon);
			}
			if (con.State == ConnectionState.Closed)
				con.Open();
		}
		//关闭数据库连接
		public void Close()
		{
			if (con != null)
				con.Close();
		}

		//重载查询 返回数据
		public DataView RunSelectSQL(string sqlstr)
		{
			this.Open();
			DataSet ds = new DataSet();
			SqlDataAdapter ada = new SqlDataAdapter(sqlstr, con);
			ada.Fill(ds);
			return ds.Tables[0].DefaultView;
		}
		public DataSet RunSelecctSQL(string sqlstr, bool b)
		{
			this.Open();
			DataSet ds = new DataSet();
			SqlDataAdapter ada = new SqlDataAdapter(sqlstr, con);
			ada.Fill(ds);
			return ds;
		}


		//增删改 是否成功
		public bool RunModifySQL(string sqlstr)
		{
			this.Open();
			com = new SqlCommand(sqlstr, con);
			try
			{
				com.ExecuteNonQuery();
				return true;
			}
			catch { return false; }
		}


	}
}
