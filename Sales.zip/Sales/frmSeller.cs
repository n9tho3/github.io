﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;
using System.Windows.Forms.VisualStyles;

namespace Sales
{
	public partial class frmSeller : Form
	{
		public frmSeller()
		{
			InitializeComponent();
		}
		//储存表
		public DataView myDataView = new DataView();
		//储存行
		public DataRowView myRow;

		//储存行数
		public int iCurrentRow;


		private void frmSeller_Load(object sender, EventArgs e)
		{
			DataBase db = new DataBase();
			myDataView = db.RunSelectSQL("Select SaleID,Salename,sex,birthday,hiredate,address,telephone,notes from seller");
			db.Close();
		}
		//载入Seller当前表
		private void LoadDataSet()
		{
			DataBase db = new DataBase();
			myDataView = db.RunSelectSQL("select SaleID,Salename,Sex,Birthday,HireDate,Address,Telephone,Notes from Seller");
			db.Close();
		}

		//窗体控件加载数据
		private void showData()
		{
			if (myDataView.Count > 0)
			{
				//获取表中所需行
				myRow = myDataView[iCurrentRow];

				this.txtNo.Text = myRow["SaleID"].ToString();
				this.txtName.Text = myRow["Salename"].ToString();
				this.txtSex.Text = myRow["Sex"].ToString();
				this.dtpBirthday.Text = myRow["Birthday"].ToString();
				this.dtpHiretime.Text = myRow["HireDate"].ToString();
				this.txtAddress.Text = myRow["Address"].ToString();
				this.txtPhone.Text = myRow["Telephone"].ToString();
				this.txtNotes.Text = myRow["Notes"].ToString();

			} else
			{
				this.txtNo.Text = "";
				this.txtName.Text = "";
				this.txtAddress.Text = "";
				this.txtNotes.Text = "";
				this.txtSex.Text = "";
				this.txtPhone.Text = "";
				this.dtpBirthday.Text = "";
				this.dtpHiretime.Text = "";

				this.btnNavFirst.Enabled = false;
				this.btnNavPrev.Enabled = false;
				this.btnNavNext.Enabled = false;
				this.btnLast.Enabled = false;

				this.btnAdd.Enabled = false;
				this.btnDelete.Enabled = true;
				this.btnCancel.Enabled = true;
				this.txtNo.Focus();

			}
		}

		private void btnNavFirst_Click(object sender, EventArgs e)
		{
			iCurrentRow = 0;
			this.btnNavFirst.Enabled = false;
			this.btnNavPrev.Enabled = false;
			this.btnNavNext.Enabled = false;
			this.btnLast.Enabled = false;
			showData();
		}

		private void btnNavPrev_Click(object sender, EventArgs e)
		{
			btnNavPrev.Enabled = true;

			btnLast.Enabled = true;
			iCurrentRow = iCurrentRow - 1;
			if (iCurrentRow < 0)
			{
				iCurrentRow = 0;
				btnNavPrev.Enabled = false;
				btnNavFirst.Enabled = false;
			}
			showData();
		}

		private void btnNavNext_Click(object sender, EventArgs e)
		{
			btnNavPrev.Enabled = true;
			btnNavFirst.Enabled = true;
			iCurrentRow = iCurrentRow + 1;
			if (iCurrentRow > myDataView.Count - 1)
			{
				iCurrentRow = myDataView.Count - 1;
				btnNavNext.Enabled = false;
				btnLast.Enabled = false;
			}
			showData();
		}

		private void btnLast_Click(object sender, EventArgs e)
		{
			iCurrentRow = myDataView.Count - 1;
			btnLast.Enabled = false;
			btnNavNext.Enabled = false;
			btnNavFirst.Enabled = true;
			btnNavPrev.Enabled = true;
			if (iCurrentRow > 0)
			{
				showData();
			}
		}

		private void btnAdd_Click(object sender, EventArgs e)
		{
			txtNo.Text = "";
			txtName.Text = "";
			txtSex.Text = "";
			dtpBirthday.Text = "";
			dtpHiretime.Text = "";
			txtAddress.Text = "";
			txtPhone.Text = "";
			txtNotes.Text = "";

			btnNavFirst.Enabled = false;
			btnNavPrev.Enabled = false;
			btnNavNext.Enabled = false;
			btnLast.Enabled = false;

			btnAdd.Enabled = false;
			btnDelete.Enabled = false;
			btnUpdate.Enabled = false;

			btnSave.Enabled = true;
			btnCancel.Enabled = true;
			txtNo.Focus();
		}

		private void btnSave_Click(object sender, EventArgs e)
		{
			DataBase db = new DataBase();
			if (txtNo.Text.Trim().Length == 0)
			{
				MessageBox.Show("编号不能为空");
				txtNo.Focus();
				return;
			}
			try
			{
				db.Open();
				SqlCommand cmd = new SqlCommand("insertSeller", db.Con);
				cmd.CommandType = CommandType.StoredProcedure;

				cmd.Parameters.Add("@SaleID", SqlDbType.NVarChar, 3).Value = txtNo.Text;
				cmd.Parameters.Add("@Salename", SqlDbType.NVarChar, 8).Value = txtName.Text;
				cmd.Parameters.Add("@Sex", SqlDbType.NVarChar, 2).Value = txtSex.Text;
				cmd.Parameters.Add("@Birthday", SqlDbType.DateTime).Value = dtpBirthday.Value;
				cmd.Parameters.Add("@HireDate", SqlDbType.DateTime).Value = dtpHiretime.Value;
				cmd.Parameters.Add("@Address", SqlDbType.NVarChar, 60).Value = txtAddress.Text;
				cmd.Parameters.Add("@Telephone", SqlDbType.NVarChar, 13).Value = txtPhone.Text;
				cmd.Parameters.Add("@Notes", SqlDbType.NVarChar, 200).Value = txtNotes.Text;

				cmd.ExecuteNonQuery();
				db.Close();
				db = null;
				MessageBox.Show("添加记录成功", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
				LoadDataSet();
				iCurrentRow = myDataView.Count - 1;
				showData();

				//恢复按钮状态
				btnNavFirst.Enabled = true;
				btnNavPrev.Enabled = true;
				btnNavNext.Enabled = true;
				btnLast.Enabled = true;

				btnAdd.Enabled = true;
				btnDelete.Enabled = true;
				btnUpdate.Enabled = true;

				btnSave.Enabled = false;
				btnCancel.Enabled = false;
				btnAdd.Focus();

			}
			catch (Exception ex)
			{
				MessageBox.Show("添加记录失败" + ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private void btnUpdate_Click(object sender, EventArgs e)
		{
			DataBase db = new DataBase();
			try
			{
				db.Open();
				SqlCommand cmd = new SqlCommand("UpdateSeller", db.Con);
				cmd.CommandType = CommandType.StoredProcedure;
				cmd.Parameters.Add("@SaleID", SqlDbType.NVarChar, 3).Value = txtNo.Text;
				cmd.Parameters.Add("@Salename", SqlDbType.NVarChar, 8).Value = txtName.Text;
				cmd.Parameters.Add("@Sex", SqlDbType.NVarChar, 2).Value = txtSex.Text;
				cmd.Parameters.Add("@Birthday", SqlDbType.DateTime).Value = dtpBirthday.Value;
				cmd.Parameters.Add("@HireDate", SqlDbType.DateTime).Value = dtpHiretime.Value;
				cmd.Parameters.Add("@Address", SqlDbType.NVarChar, 60).Value = txtAddress.Text;
				cmd.Parameters.Add("@Telephone", SqlDbType.NVarChar, 13).Value = txtPhone.Text;
				cmd.Parameters.Add("@Notes", SqlDbType.NVarChar, 200).Value = txtNotes.Text;

				cmd.ExecuteNonQuery();
				db.Close();
				db = null;
				LoadDataSet();
				MessageBox.Show("更新记录成功", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
			catch (Exception ex)
			{
				MessageBox.Show("更新记录失败" + ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private void btnDelete_Click(object sender, EventArgs e)
		{
			if (MessageBox.Show("确定要删除该记录吗？", "确认信息", 
				MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.Cancel)
			{
				return;
			}
			DataBase db = new DataBase();
			try 
			{ 
				db.Open();
				SqlCommand cmd = new SqlCommand("DeleteSeller", db.Con);
				cmd.CommandType=CommandType.StoredProcedure;
				cmd.Parameters.Add("@SaleID",SqlDbType.NVarChar,3).Value=txtNo.Text;
				cmd.ExecuteNonQuery();
				db.Close();
				db = null;
				MessageBox.Show("删除记录成功",this.Text,MessageBoxButtons.OK, MessageBoxIcon.Information);

				if (iCurrentRow > 0) 
				{ 
					iCurrentRow=iCurrentRow-1; 
				}
				else { 
					iCurrentRow=0;
					LoadDataSet();
					showData();
				}
			}
			catch (Exception ex) 
			{ 
				MessageBox.Show("删除记录失败。" + ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error); 
			}
		}

		//回车跳转下一个
		private void frmSeller_KeyPress(object sender, KeyPressEventArgs e)
		{
			if (e.KeyChar == (char)Keys.Return)
			{
				e.Handled = true;
				SendKeys.Send("{TAB}");
			}
		}
	}
}
