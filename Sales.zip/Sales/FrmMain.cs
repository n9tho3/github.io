﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Sales
{
	public partial class FrmMain : Form
	{
		public FrmMain()
		{
			InitializeComponent();
		}

		private void menuStrip1_Click(object sender, EventArgs e)
		{
			
		}


		private void FrmMain_FormClosing(object sender, FormClosingEventArgs e)
		{
			if (DialogResult.Yes == MessageBox.Show("你确定要关闭吗？", "提示",
	MessageBoxButtons.YesNo, MessageBoxIcon.Question))
			{
				e.Cancel = false;
			}
			else {
				e.Cancel = true; 
			}
		}

		private void 销售员信息ToolStripMenuItem_Click(object sender, EventArgs e)
		{
			frmSeller childFrm=new frmSeller();
			//childFrm.MdiParent = this;
			childFrm.ShowDialog();
		}
	}
}
