﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;

namespace Sales
{
	public partial class Form2 : Form
	{
		public Form2()
		{
			InitializeComponent();
		}

		private void btnLogin_Click(object sender, EventArgs e)
		{
			DataBase db=new DataBase();
			string str;
			if((txtUserName.Text.Trim()=="")||(txtPwd.Text.Trim()==""))
			{
				MessageBox.Show("请输入用户名和密码。",this.Text,
					MessageBoxButtons.OK,MessageBoxIcon.Warning);
				return;
			}
			try
			{
				str = "select UserName,Password from [user] where UserName='" +
					txtUserName.Text.Trim() + "'and password='" + txtPwd.Text.Trim() + "'";
				if (db.RunSelectSQL(str).Count >= 1)
				{
					FrmMain obj = new FrmMain();
					obj.Show();
					this.Hide();
				}
				else
				{
					MessageBox.Show("用户名或密码有错误。", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
				}
			}
			catch
			{
				MessageBox.Show("数据库服务器连接失败。",this.Text,MessageBoxButtons.OK,MessageBoxIcon.Error);
			}
			finally 
			{
				db.Close();
				db = null;
			}
		}

		private void btnCancel_Click(object sender, EventArgs e)
		{
			this.Close();
		}
	}
}
