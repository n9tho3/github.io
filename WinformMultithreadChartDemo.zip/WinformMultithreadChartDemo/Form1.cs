﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace WinformMultithreadChartDemo
{
    public partial class Form1 : Form
    {
        #region 全局变量定义
        // 模拟4台工业设备同时采集
        private readonly int _deviceCount = 4;
        // 取消令牌：用来停止后台采集任务
        private CancellationTokenSource _cts;
        // 存储每台设备最新的采集数据
        private Dictionary<int, double> _currentDeviceData = new Dictionary<int, double>();
        // 统计正常/异常数据次数
        private int _errorCount = 0;
        private int _normalCount = 0;
        #endregion

        public Form1()
        {
            InitializeComponent();
            // 启动的时候初始化图表和数据
            InitChart();
            InitDeviceData();
        }

        #region 第一步：初始化三个图表，把基础配置做好
        private void InitChart()
        {
            // 1. 初始化折线图：看温度随时间变化趋势
            InitLineChart();
            // 2. 初始化柱状图：对比不同设备的负载
            InitBarChart();
            // 3. 初始化饼图：看正常/异常数据占比
            InitPieChart();
        }

        // 初始化折线图
        private void InitLineChart()
        {
            var lineChart = chartRealTrend;
            // 先清空原来的内容
            lineChart.ChartAreas.Clear();
            // 创建一个绘图区域
            ChartArea area = new ChartArea("DefaultArea");

            // 开启图表的缩放、平移功能：框选就能放大看细节，这是常用功能
            area.CursorX.IsUserEnabled = true;
            area.CursorX.IsUserSelectionEnabled = true;
            area.CursorY.IsUserEnabled = true;
            area.CursorY.IsUserSelectionEnabled = true;

            // 设置坐标轴标题
            area.AxisX.Title = "时间";
            area.AxisY.Title = "设备温度(℃)";
            lineChart.ChartAreas.Add(area);

            // 添加曲线：每个设备一条单独的线
            lineChart.Series.Clear();
            for (int i = 1; i <= _deviceCount; i++)
            {
                Series series = new Series($"设备{i}");
                series.ChartType = SeriesChartType.Line; // 设置为折线图
                series.BorderWidth = 2; // 线宽
                series.IsVisibleInLegend = true; // 在图例显示
                lineChart.Series.Add(series);
            }
            // 添加图例和标题
            lineChart.Legends.Add(new Legend("设备图例"));
            lineChart.Titles.Add("设备温度实时趋势");
        }

        // 初始化柱状图
        private void InitBarChart()
        {
            var barChart = chartBarLoad;
            barChart.ChartAreas.Clear();
            ChartArea area = new ChartArea("BarArea");
            area.AxisX.Title = "设备编号";
            area.AxisY.Title = "当前CPU负载(%)";
            barChart.ChartAreas.Add(area);

            barChart.Series.Clear();
            Series loadSeries = new Series("设备负载");
            loadSeries.ChartType = SeriesChartType.Column; // 柱状图类型
            loadSeries.IsValueShownAsLabel = true; // 柱子上面显示具体数值，一目了然
            loadSeries["PointWidth"] = "0.6"; // 设置柱子宽度
            // 给每个设备加一个柱子，初始值0
            for (int i = 1; i <= _deviceCount; i++)
            {
                loadSeries.Points.AddXY($"设备{i}", 0);
            }
            barChart.Series.Add(loadSeries);
            barChart.Legends.Clear(); // 不需要图例，直接显示
            barChart.Titles.Add("当前设备负载对比");
        }

        // 初始化饼图
        private void InitPieChart()
        {
            var pieChart = chartPieStatus;
            pieChart.ChartAreas.Clear();
            pieChart.ChartAreas.Add(new ChartArea("PieArea"));

            pieChart.Series.Clear();
            Series statusSeries = new Series("设备状态");
            statusSeries.ChartType = SeriesChartType.Pie; // 饼图类型
            statusSeries.IsValueShownAsLabel = true; // 显示标签
            statusSeries.Label = "#PERCENT{P0} #VALY"; // 显示：百分比 + 具体次数
            statusSeries["PieLabelStyle"] = "Outside"; // 标签放在饼图外面，不会挡着内容
            // 两个分类：正常运行、异常报警，初始全正常
            statusSeries.Points.AddXY("正常运行", 4);
            statusSeries.Points.AddXY("异常报警", 0);
            pieChart.Series.Add(statusSeries);
            pieChart.Legends.Add(new Legend("状态分类"));
            pieChart.Titles.Add("设备运行状态分布");
        }

        // 初始化设备数据
        private void InitDeviceData()
        {
            for (int i = 1; i <= _deviceCount; i++)
            {
                _currentDeviceData[i] = 0;
            }
            _normalCount = _deviceCount;
            _errorCount = 0;
        }
        #endregion

        #region 第二步：多线程并发采集逻辑
        // 点击启动采集按钮
        private async void btnStart_Click(object sender, EventArgs e)
        {
            // 如果已经在采集了，提示用户
            if (_cts != null && !_cts.IsCancellationRequested)
            {
                MessageBox.Show("采集已经在运行中，请先停止");
                return;
            }

            // 初始化取消令牌，修改按钮状态
            _cts = new CancellationTokenSource();
            btnStart.Enabled = false;
            btnStop.Enabled = true;

            try
            {
                // 每个设备一个独立的后台任务，模拟多设备并发采集（就是多线程的用法）
                List<Task> collectTasks = new List<Task>();
                for (int deviceId = 1; deviceId <= _deviceCount; deviceId++)
                {
                    int id = deviceId; // 闭包拷贝，避免参数错误
                    // 启动后台任务，每个设备自己循环采集
                    var task = Task.Run(() => DeviceCollectLoop(id, _cts.Token), _cts.Token);
                    collectTasks.Add(task);
                }

                // 主循环：每隔500毫秒更新一次UI，不会卡界面
                while (!_cts.IsCancellationRequested)
                {
                    UpdateAllChart(); // 更新所有图表
                    await Task.Delay(500, _cts.Token); // 等待500毫秒
                }
            }
            catch (OperationCanceledException)
            {
                // 点击停止后正常退出，不用处理
            }
            finally
            {
                // 恢复按钮状态
                btnStart.Enabled = true;
                btnStop.Enabled = false;
            }
        }

        // 单个设备的采集循环：后台线程运行，不会卡UI
        private async Task DeviceCollectLoop(int deviceId, CancellationToken token)
        {
            // 每个设备用不同的随机种子，保证数据不一样
            Random rand = new Random(deviceId * Environment.TickCount);
            // 一直采集，直到用户点击停止
            while (!token.IsCancellationRequested)
            {
                // 模拟不同设备的采集间隔，和真实工业场景一样，采集速度不一样
                int interval = rand.Next(200, 800);
                await Task.Delay(interval, token);

                // 模拟生成采集数据：温度在30℃到80℃之间
                double newTemp = Math.Round(rand.NextDouble() * 50 + 30, 1);

                // 锁：多个线程同时改数据的时候，保证不会出错（线程安全）
                lock (_currentDeviceData)
                {
                    _currentDeviceData[deviceId] = newTemp;
                    // 统计异常：超过70℃算异常
                    if (newTemp > 70)
                        _errorCount++;
                    else
                        _normalCount++;
                }
            }
        }

        // 点击停止采集按钮
        private void btnStop_Click(object sender, EventArgs e)
        {
            _cts?.Cancel(); // 通知所有后台任务停止
        }
        #endregion

        #region 第三步：更新图表到UI
        private void UpdateAllChart()
        {
            // 如果当前不是UI线程，就把方法转到UI线程执行
            // 这很重要：WinForm只能在UI线程改控件，不然会报错
            if (this.InvokeRequired)
            {
                this.Invoke(new Action(UpdateAllChart));
                return;
            }

            // 加锁，读数据的时候不会被后台线程改，保证数据一致
            lock (_currentDeviceData)
            {
                UpdateLineChart();
                UpdateBarChart();
                UpdatePieChart();
            }
        }

        // 更新折线图：追加最新的温度数据
        private void UpdateLineChart()
        {
            string timeStr = DateTime.Now.ToString("HH:mm:ss");
            for (int i = 1; i <= _deviceCount; i++)
            {
                var series = chartRealTrend.Series[$"设备{i}"];
                // 把最新时间和温度加到折线里
                series.Points.AddXY(timeStr, _currentDeviceData[i]);
                // 只保留最近20个点，数据太多会让图表变卡，避免内存溢出
                if (series.Points.Count > 20)
                {
                    series.Points.RemoveAt(0);
                }
            }
        }

        // 更新柱状图：修改每个设备的负载高度
        private void UpdateBarChart()
        {
            var series = chartBarLoad.Series[0];
            for (int i = 1; i <= _deviceCount; i++)
            {
                // 负载和温度正相关：温度越高，负载越高
                double load = Math.Round(_currentDeviceData[i] / 80 * 100, 1);
                // 修改柱子的高度
                series.Points[i - 1].YValues[0] = load;
                // 超过80%负载就把柱子标红，提示异常
                if (load > 80)
                {
                    series.Points[i - 1].Color = System.Drawing.Color.Red;
                }
                else
                {
                    series.Points[i - 1].Color = System.Drawing.Color.SteelBlue;
                }
            }
        }

        // 更新饼图：修改正常/异常的占比
        private void UpdatePieChart()
        {
            var series = chartPieStatus.Series[0];
            series.Points[0].YValues[0] = _normalCount;
            series.Points[1].YValues[0] = _errorCount;
        }
        #endregion

        #region 附加功能：保存当前图表为图片
        private void btnSaveChart_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog sfd = new SaveFileDialog())
            {
                sfd.Filter = "PNG图片|*.png|JPG图片|*.jpg";
                sfd.FileName = $"设备监控图表_{DateTime.Now:yyyyMMddHHmmss}";
                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    // 原生Chart直接支持保存图片，不用额外写代码
                    if (tabControl1.SelectedTab == tabPage1)
                        chartRealTrend.SaveImage(sfd.FileName, System.Drawing.Imaging.ImageFormat.Png);
                    else if (tabControl1.SelectedTab == tabPage2)
                        chartBarLoad.SaveImage(sfd.FileName, System.Drawing.Imaging.ImageFormat.Png);
                    else
                        chartPieStatus.SaveImage(sfd.FileName, System.Drawing.Imaging.ImageFormat.Png);
                    MessageBox.Show("图表保存成功！");
                }
            }
        }
        #endregion

        // 关闭窗体的时候，自动停止所有后台任务
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            _cts?.Cancel();
            base.OnFormClosing(e);
        }
    }
}
